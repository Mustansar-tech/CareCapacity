# Data Cleaning – Care Hours vs Client Demand

This project turns two weekly exports into a clean, app‑ready dataset.

## Inputs
1. **Availability Export.xlsx** (sheet: `CAREGiver Availability`)
2. **Care Pro Guaranteed Hours.xlsx** (sheet: `Data` with columns:
   - `Actual Employee Name`
   - `Actual Employee Hours Per Week`)

## Output
- **cleaned_capacity.xlsx** with columns:
  `Employee Name, Contracted Weekly Hours, Contracted Daily Hours, Date, Status, Time Windows, Hours, Net Capacity, Notes`

## Rules (Option 2 – Enhanced)
- Robust name normalisation and fuzzy matching (drops titles, `(NL)/(GH)`, punctuation; lowercase; token‑sort).
- `Contracted Daily Hours = Weekly ÷ unique days present in availability`.
- Group by **Employee + Date** and keep all non‑overlapping statuses.
- If statuses overlap, apply priority:
  `Maternity > Sick > Holiday > Compassionate Leave > Other Unavailable > Pre-Agreed Appointment > Available`.
- Cap leave hours at daily contract; **Available = daily − capped leave (>=0)**.
- Leave rows have `Net Capacity = 0`; Available rows carry the adjusted usable hours.
- Time windows and Notes are concatenated for transparency.

## How to run
From a terminal (Python 3.9+):
```bash
pip install -r requirements.txt
python cleaner.py   --availability "/path/to/Availability Export.xlsx"   --guaranteed "/path/to/Care Pro Guaranteed Hours.xlsx"   --out "/path/to/cleaned_capacity.xlsx"
```

> Tip: Put all files in the same folder and run without `--out` to create `cleaned_capacity.xlsx` next to the inputs.
